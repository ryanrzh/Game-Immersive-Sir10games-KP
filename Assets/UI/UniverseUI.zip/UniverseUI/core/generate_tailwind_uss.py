#!/usr/bin/env python3
"""
Generator "Tailwind untuk Unity UI Toolkit" -> menghasilkan tailwind.uss

Pakai:  python generate_tailwind_uss.py [output.uss]

Aturan penamaan (karena USS tidak boleh pakai ':' '/' '.' di nama class):
  p-4            -> padding 16px (1 unit = 4px, sama seperti Tailwind)
  p-0_5          -> titik diganti underscore   (p-0.5)
  w-1_2          -> pecahan                     (w-1/2)
  bg-blue-500_50 -> opacity (hanya black/white) (bg-blue-500/50)
  neg-mt-4       -> margin negatif              (-mt-4)
  hover-bg-blue-600  -> state hover             (hover:bg-blue-600)
Ubah konfigurasi di bagian CONFIG kalau mau menyesuaikan.
"""
import sys
from pathlib import Path

# ----------------------------------------------------------------- CONFIG
UNIT = 4                       # 1 skala spacing = 4px
OPACITY_STEPS = [5, 10, 20, 25, 30, 40, 50, 60, 70, 75, 80, 90, 95]
OPACITY_FOR_ALL_COLORS = False  # True -> bg-<warna>-<shade>_<opacity> utk semua warna (file jadi besar)
STATES = ["hover", "active", "focus", "disabled"]
# -----------------------------------------------------------------------

SHADES = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]
PALETTE = {
    "slate":  "f8fafc f1f5f9 e2e8f0 cbd5e1 94a3b8 64748b 475569 334155 1e293b 0f172a 020617",
    "gray":   "f9fafb f3f4f6 e5e7eb d1d5db 9ca3af 6b7280 4b5563 374151 1f2937 111827 030712",
    "red":    "fef2f2 fee2e2 fecaca fca5a5 f87171 ef4444 dc2626 b91c1c 991b1b 7f1d1d 450a0a",
    "orange": "fff7ed ffedd5 fed7aa fdba74 fb923c f97316 ea580c c2410c 9a3412 7c2d12 431407",
    "yellow": "fefce8 fef9c3 fef08a fde047 facc15 eab308 ca8a04 a16207 854d0e 713f12 422006",
    "green":  "f0fdf4 dcfce7 bbf7d0 86efac 4ade80 22c55e 16a34a 15803d 166534 14532d 052e16",
    "blue":   "eff6ff dbeafe bfdbfe 93c5fd 60a5fa 3b82f6 2563eb 1d4ed8 1e40af 1e3a8a 172554",
    "indigo": "eef2ff e0e7ff c7d2fe a5b4fc 818cf8 6366f1 4f46e5 4338ca 3730a3 312e81 1e1b4b",
    "purple": "faf5ff f3e8ff e9d5ff d8b4fe c084fc a855f7 9333ea 7e22ce 6b21a8 581c87 3b0764",
    "pink":   "fdf2f8 fce7f3 fbcfe8 f9a8d4 f472b6 ec4899 db2777 be185d 9d174d 831843 500724",
}

SPACING = ["0", "0.5", "1", "1.5", "2", "2.5", "3", "3.5", "4", "5", "6", "7", "8", "9",
           "10", "11", "12", "14", "16", "20", "24", "28", "32", "36", "40", "44", "48",
           "52", "56", "60", "64", "72", "80", "96"]

FRACTIONS = [(1, 2), (1, 3), (2, 3), (1, 4), (3, 4), (1, 5), (2, 5), (3, 5), (4, 5), (1, 6), (5, 6)]

out = []


def c(s):  # nama class aman
    return str(s).replace(".", "_")


def px(k):
    return f"{float(k) * UNIT:g}px"


def section(title):
    out.append(f"\n/* ===== {title} ===== */")


def r(sel, decl, pseudo=""):
    out.append(f".{sel}{pseudo} {{ {decl} }}")


def hex_rgb(h):
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


# ---- daftar warna: nama -> nilai USS
COLORS = {"white": "#ffffff", "black": "#000000", "transparent": "rgba(0, 0, 0, 0)"}
for name, hexes in PALETTE.items():
    for shade, h in zip(SHADES, hexes.split()):
        COLORS[f"{name}-{shade}"] = f"#{h}"

COLOR_PROPS = {
    "bg": "background-color",
    "text": "color",
    "border": "border-color",
    "tint": "-unity-background-image-tint-color",
}


def with_alpha(value, a):
    if value.startswith("#"):
        R, G, B = hex_rgb(value[1:])
        return f"rgba({R}, {G}, {B}, {a:g})"
    return value


out.append("/* tailwind.uss - dibuat otomatis oleh generate_tailwind_uss.py. Jangan edit manual. */")

# ------------------------------------------------------------------ LAYOUT
section("Display / Position / Visibility")
r("flex", "display: flex;")
r("hidden", "display: none;")
r("visible", "visibility: visible;")
r("invisible", "visibility: hidden;")
r("absolute", "position: absolute;")
r("relative", "position: relative;")
r("overflow-hidden", "overflow: hidden;")
r("overflow-visible", "overflow: visible;")

section("Flexbox")
r("flex-row", "flex-direction: row;")
r("flex-col", "flex-direction: column;")
r("flex-row-reverse", "flex-direction: row-reverse;")
r("flex-col-reverse", "flex-direction: column-reverse;")
r("flex-wrap", "flex-wrap: wrap;")
r("flex-nowrap", "flex-wrap: nowrap;")
r("flex-wrap-reverse", "flex-wrap: wrap-reverse;")
r("flex-1", "flex-grow: 1; flex-shrink: 1; flex-basis: 0;")
r("flex-auto", "flex-grow: 1; flex-shrink: 1; flex-basis: auto;")
r("flex-initial", "flex-grow: 0; flex-shrink: 1; flex-basis: auto;")
r("flex-none", "flex-grow: 0; flex-shrink: 0; flex-basis: auto;")
r("grow", "flex-grow: 1;")
r("grow-0", "flex-grow: 0;")
r("shrink", "flex-shrink: 1;")
r("shrink-0", "flex-shrink: 0;")
for n, v in {"start": "flex-start", "center": "center", "end": "flex-end", "stretch": "stretch"}.items():
    r(f"items-{n}", f"align-items: {v};")
    r(f"self-{n}", f"align-self: {v};")
    r(f"content-{n}", f"align-content: {v};")
r("self-auto", "align-self: auto;")
for n, v in {"start": "flex-start", "center": "center", "end": "flex-end",
             "between": "space-between", "around": "space-around"}.items():
    r(f"justify-{n}", f"justify-content: {v};")

section("Gap (diemulasi lewat margin anak)")
# Setiap anak langsung dapat margin di sisi belakang. Anak terakhir ikut kena margin,
# jadi beri class 'mr-0' (untuk gap-x) atau 'mb-0' (untuk gap-y) pada anak terakhir.
# Bagian ini sengaja diletakkan SEBELUM bagian Margin supaya mr-0/mb-0 menang.
for k in SPACING:
    out.append(f".gap-x-{c(k)} > * {{ margin-right: {px(k)}; }}")
    out.append(f".gap-y-{c(k)} > * {{ margin-bottom: {px(k)}; }}")

# ----------------------------------------------------------------- SPACING
section("Padding")
for k in SPACING:
    v, n = px(k), c(k)
    r(f"p-{n}", f"padding: {v};")
    r(f"px-{n}", f"padding-left: {v}; padding-right: {v};")
    r(f"py-{n}", f"padding-top: {v}; padding-bottom: {v};")
    for s, side in (("t", "top"), ("r", "right"), ("b", "bottom"), ("l", "left")):
        r(f"p{s}-{n}", f"padding-{side}: {v};")

section("Margin")
for k in SPACING:
    v, n = px(k), c(k)
    r(f"m-{n}", f"margin: {v};")
    r(f"mx-{n}", f"margin-left: {v}; margin-right: {v};")
    r(f"my-{n}", f"margin-top: {v}; margin-bottom: {v};")
    for s, side in (("t", "top"), ("r", "right"), ("b", "bottom"), ("l", "left")):
        r(f"m{s}-{n}", f"margin-{side}: {v};")
r("m-auto", "margin: auto;")
r("mx-auto", "margin-left: auto; margin-right: auto;")
r("my-auto", "margin-top: auto; margin-bottom: auto;")
for s, side in (("t", "top"), ("r", "right"), ("b", "bottom"), ("l", "left")):
    r(f"m{s}-auto", f"margin-{side}: auto;")

section("Margin negatif (neg-*)")
for k in SPACING[1:]:
    v, n = px(k), c(k)
    r(f"neg-m-{n}", f"margin: -{v};")
    r(f"neg-mx-{n}", f"margin-left: -{v}; margin-right: -{v};")
    r(f"neg-my-{n}", f"margin-top: -{v}; margin-bottom: -{v};")
    for s, side in (("t", "top"), ("r", "right"), ("b", "bottom"), ("l", "left")):
        r(f"neg-m{s}-{n}", f"margin-{side}: -{v};")

# ------------------------------------------------------------------ SIZING
section("Width / Height / Min / Max")
SIZE_PROPS = {"w": "width", "h": "height", "min-w": "min-width", "min-h": "min-height",
              "max-w": "max-width", "max-h": "max-height"}
for pre, prop in SIZE_PROPS.items():
    for k in SPACING:
        r(f"{pre}-{c(k)}", f"{prop}: {px(k)};")
    r(f"{pre}-px", f"{prop}: 1px;")
    r(f"{pre}-full", f"{prop}: 100%;")
    for a, b in FRACTIONS:
        r(f"{pre}-{a}_{b}", f"{prop}: {a / b * 100:.4f}%;".replace(".0000%", "%"))
r("w-auto", "width: auto;")
r("h-auto", "height: auto;")
r("max-w-none", "max-width: none;")
r("max-h-none", "max-height: none;")
r("size-full", "width: 100%; height: 100%;")
for k in SPACING:
    r(f"size-{c(k)}", f"width: {px(k)}; height: {px(k)};")

section("Position offsets (top/right/bottom/left/inset)")
for k in SPACING:
    v, n = px(k), c(k)
    r(f"top-{n}", f"top: {v};")
    r(f"right-{n}", f"right: {v};")
    r(f"bottom-{n}", f"bottom: {v};")
    r(f"left-{n}", f"left: {v};")
    r(f"inset-{n}", f"top: {v}; right: {v}; bottom: {v}; left: {v};")
    r(f"inset-x-{n}", f"left: {v}; right: {v};")
    r(f"inset-y-{n}", f"top: {v}; bottom: {v};")
for side in ("top", "right", "bottom", "left"):
    r(f"{side}-full", f"{side}: 100%;")
r("inset-0", "top: 0; right: 0; bottom: 0; left: 0;")

# -------------------------------------------------------------- TYPOGRAPHY
section("Typography")
for n, v in {"xs": 12, "sm": 14, "base": 16, "lg": 18, "xl": 20, "2xl": 24, "3xl": 30,
             "4xl": 36, "5xl": 48, "6xl": 60, "7xl": 72}.items():
    r(f"text-{n}", f"font-size: {v}px;")
r("font-normal", "-unity-font-style: normal;")
r("font-bold", "-unity-font-style: bold;")
r("italic", "-unity-font-style: italic;")
r("font-bold-italic", "-unity-font-style: bold-and-italic;")
for n, v in {"left": "left", "center": "center", "right": "right"}.items():
    r(f"text-{n}", f"-unity-text-align: upper-{v};")
    r(f"text-mid-{n}", f"-unity-text-align: middle-{v};")
    r(f"text-lower-{n}", f"-unity-text-align: lower-{v};")
r("truncate", "overflow: hidden; text-overflow: ellipsis; white-space: nowrap;")
r("text-ellipsis", "text-overflow: ellipsis;")
r("text-clip", "text-overflow: clip;")
r("whitespace-normal", "white-space: normal;")
r("whitespace-nowrap", "white-space: nowrap;")
for n, v in {"tighter": -0.8, "tight": -0.4, "normal": 0, "wide": 0.4, "wider": 0.8, "widest": 1.6}.items():
    r(f"tracking-{n}", f"letter-spacing: {v:g}px;")

# ------------------------------------------------------------------ COLORS
section("Warna: bg-*, text-*, border-*, tint-*")
for pre, prop in COLOR_PROPS.items():
    for name, val in COLORS.items():
        r(f"{pre}-{name}", f"{prop}: {val};")
        if name in ("white", "black") or OPACITY_FOR_ALL_COLORS:
            if name == "transparent":
                continue
            for o in OPACITY_STEPS:
                r(f"{pre}-{name}_{o}", f"{prop}: {with_alpha(val, o / 100)};")

section("State warna: hover-/active-/focus-/disabled-")
for st in STATES:
    for pre in ("bg", "text", "border"):
        prop = COLOR_PROPS[pre]
        for name, val in COLORS.items():
            r(f"{st}-{pre}-{name}", f"{prop}: {val};", f":{st}")
        for name in ("white", "black"):
            for o in OPACITY_STEPS:
                r(f"{st}-{pre}-{name}_{o}", f"{prop}: {with_alpha(COLORS[name], o / 100)};", f":{st}")

# ----------------------------------------------------------------- BORDERS
section("Border width")
r("border", "border-width: 1px;")
for w in (0, 2, 4, 8):
    r(f"border-{w}", f"border-width: {w}px;")
for s, side in (("t", "top"), ("r", "right"), ("b", "bottom"), ("l", "left")):
    r(f"border-{s}", f"border-{side}-width: 1px;")
    for w in (0, 2, 4, 8):
        r(f"border-{s}-{w}", f"border-{side}-width: {w}px;")

section("Border radius")
RADIUS = {"none": 0, "sm": 2, "": 4, "md": 6, "lg": 8, "xl": 12, "2xl": 16, "3xl": 24, "full": 9999}
for n, v in RADIUS.items():
    suf = f"-{n}" if n else ""
    r(f"rounded{suf}", f"border-radius: {v}px;")
    r(f"rounded-t{suf}", f"border-top-left-radius: {v}px; border-top-right-radius: {v}px;")
    r(f"rounded-b{suf}", f"border-bottom-left-radius: {v}px; border-bottom-right-radius: {v}px;")
    r(f"rounded-l{suf}", f"border-top-left-radius: {v}px; border-bottom-left-radius: {v}px;")
    r(f"rounded-r{suf}", f"border-top-right-radius: {v}px; border-bottom-right-radius: {v}px;")

# ------------------------------------------------------------- BACKGROUNDS
section("Background image scale mode")
r("bg-cover", "-unity-background-scale-mode: scale-and-crop;")
r("bg-contain", "-unity-background-scale-mode: scale-to-fit;")
r("bg-fill", "-unity-background-scale-mode: stretch-to-fill;")

# ----------------------------------------------------- OPACITY / TRANSFORM
section("Opacity")
for o in range(0, 101, 5):
    r(f"opacity-{o}", f"opacity: {o / 100:g};")
    for st in STATES:
        r(f"{st}-opacity-{o}", f"opacity: {o / 100:g};", f":{st}")

section("Transform")
for d in (0, 1, 2, 3, 6, 12, 45, 90, 180):
    r(f"rotate-{d}", f"rotate: {d}deg;")
    if d:
        r(f"neg-rotate-{d}", f"rotate: -{d}deg;")
for s in (0, 50, 75, 90, 95, 100, 105, 110, 125, 150):
    r(f"scale-{s}", f"scale: {s / 100:g} {s / 100:g};")
    for st in ("hover", "active"):
        r(f"{st}-scale-{s}", f"scale: {s / 100:g} {s / 100:g};", f":{st}")

# ------------------------------------------------------------- TRANSITIONS
section("Transition")
r("transition-none", "transition-property: none;")
r("transition", "transition-property: all; transition-duration: 150ms; transition-timing-function: ease-in-out;")
r("transition-colors", "transition-property: background-color, color, border-color, -unity-background-image-tint-color; "
                       "transition-duration: 150ms; transition-timing-function: ease-in-out;")
r("transition-opacity", "transition-property: opacity; transition-duration: 150ms; transition-timing-function: ease-in-out;")
r("transition-transform", "transition-property: scale, rotate, translate; transition-duration: 150ms; transition-timing-function: ease-in-out;")
for d in (75, 100, 150, 200, 300, 500, 700, 1000):
    r(f"duration-{d}", f"transition-duration: {d}ms;")
    r(f"delay-{d}", f"transition-delay: {d}ms;")
for n, v in {"linear": "linear", "in": "ease-in", "out": "ease-out", "in-out": "ease-in-out"}.items():
    r(f"ease-{n}", f"transition-timing-function: {v};")

Path(sys.argv[1] if len(sys.argv) > 1 else "tailwind.uss").write_text("\n".join(out) + "\n", encoding="utf-8")
print(f"OK: {len(out)} baris ditulis")
