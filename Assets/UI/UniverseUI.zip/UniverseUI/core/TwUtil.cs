// TwUtil.cs - util pendek supaya kode UI tidak ribet (tanpa RegisterCallback / registered manual).
// Taruh di Assets/Scripts/ bersama TwGameUI.cs. Butuh Unity 2021.3+ (UI Toolkit runtime).
//
// Contoh singkat:
//   root.OnClick("btn-play", () => StartGame());          // cari Button/elemen berdasarkan name, lalu pasang klik
//   root.OnClickAll("slot", slot => Select(slot));        // semua elemen ber-class "slot"
//   panel.Show(); panel.Hide(); panel.SetShown(isOpen);   // lewat class "hidden"
//   root.OnKey(KeyCode.Escape, Pause);                    // tombol keyboard
//   label.CountTo(0, 1250);                               // angka berhitung naik
//   root.Delay(1.5f, () => ...);                          // jalankan nanti
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UIElements;

namespace TwUI
{
    /// <summary>Extension method untuk VisualElement: klik, hover, tampil/sembunyi, class, timer, tween, keyboard.</summary>
    public static class UiExt
    {
        // ---------------------------------------------------------------- klik / event

        /// <summary>
        /// Pasang aksi klik. Button memakai .clicked, elemen lain memakai ClickEvent,
        /// jadi pemanggilnya tidak perlu peduli jenis elemennya. Aman dipanggil pada null.
        /// </summary>
        public static T OnClick<T>(this T element, Action action) where T : VisualElement
        {
            if (element == null || action == null) return element;

            if (element is Button button) button.clicked += action;
            else element.RegisterCallback<ClickEvent>(_ => action());
            return element;
        }

        /// <summary>Cari elemen berdasarkan name lalu pasang klik: root.OnClick("btn-play", ...). Mengembalikan elemennya (bisa null).</summary>
        public static VisualElement OnClick(this VisualElement root, string name, Action action)
        {
            var element = root.Q(name);
            element.OnClick(action);
            return element;
        }

        /// <summary>Pasang klik ke semua elemen ber-class tertentu. Elemen yang diklik dikirim ke action.</summary>
        public static void OnClickAll(this VisualElement root, string className, Action<VisualElement> action)
        {
            root.Query(className: className).ForEach(element => element.OnClick(() => action(element)));
        }

        /// <summary>Aksi saat pointer masuk / keluar dari elemen.</summary>
        public static T OnHover<T>(this T element, Action enter, Action leave = null) where T : VisualElement
        {
            if (element == null) return element;
            if (enter != null) element.RegisterCallback<PointerEnterEvent>(_ => enter());
            if (leave != null) element.RegisterCallback<PointerLeaveEvent>(_ => leave());
            return element;
        }

        /// <summary>Aksi saat nilai field berubah (Slider, Toggle, TextField, Dropdown, dll): slider.OnChange(v => ...).</summary>
        public static INotifyValueChanged<TValue> OnChange<TValue>(this INotifyValueChanged<TValue> field, Action<TValue> action)
        {
            if (field != null && action != null)
                field.RegisterValueChangedCallback(evt => action(evt.newValue));
            return field;
        }

        /// <summary>Aksi saat area gelap (backdrop) modal diklik, bukan isinya.</summary>
        public static T OnBackdropClick<T>(this T backdrop, Action action) where T : VisualElement
        {
            if (backdrop == null || action == null) return backdrop;
            backdrop.RegisterCallback<ClickEvent>(evt =>
            {
                if (ReferenceEquals(evt.target, backdrop)) action();
            });
            return backdrop;
        }

        /// <summary>
        /// Aksi saat tombol keyboard ditekan. Panggil pada root UI. Root dibuat focusable supaya menerima key event;
        /// tombol diabaikan saat pengguna sedang mengetik di TextField.
        /// </summary>
        public static T OnKey<T>(this T root, KeyCode key, Action action) where T : VisualElement
        {
            if (root == null || action == null) return root;

            root.focusable = true;
            root.RegisterCallback<KeyDownEvent>(evt =>
            {
                if (evt.keyCode != key) return;
                if (evt.target is VisualElement target && target.GetFirstAncestorOfType<TextField>() != null) return;
                action();
            }, TrickleDown.TrickleDown);
            return root;
        }

        // ---------------------------------------------------------------- tampil / class / teks

        public static T Show<T>(this T element) where T : VisualElement { element?.RemoveFromClassList("hidden"); return element; }
        public static T Hide<T>(this T element) where T : VisualElement { element?.AddToClassList("hidden"); return element; }
        public static T SetShown<T>(this T element, bool shown) where T : VisualElement { element?.EnableInClassList("hidden", !shown); return element; }
        public static bool IsShown(this VisualElement element) => element != null && !element.ClassListContains("hidden");
        public static T ToggleShown<T>(this T element) where T : VisualElement { element?.SetShown(!element.IsShown()); return element; }

        /// <summary>Nyalakan / matikan satu class: el.SetClass("slot-selected", true).</summary>
        public static T SetClass<T>(this T element, string className, bool on) where T : VisualElement
        {
            element?.EnableInClassList(className, on);
            return element;
        }

        /// <summary>
        /// Ganti varian berawalan sama: el.SetVariant("rarity-", "epic") membuang rarity-* lama lalu menambah rarity-epic.
        /// Berguna untuk rarity-, toast-, btn-, dll.
        /// </summary>
        public static T SetVariant<T>(this T element, string prefix, string value) where T : VisualElement
        {
            if (element == null) return element;

            var old = new List<string>();
            foreach (var cls in element.GetClasses())
                if (cls.StartsWith(prefix, StringComparison.Ordinal)) old.Add(cls);
            foreach (var cls in old) element.RemoveFromClassList(cls);

            if (!string.IsNullOrEmpty(value)) element.AddToClassList(prefix + value);
            return element;
        }

        /// <summary>Isi teks Label/Button berdasarkan name: root.SetText("gold-amount", "12,450").</summary>
        public static TextElement SetText(this VisualElement root, string name, string text)
        {
            var element = root.Q<TextElement>(name);
            if (element != null) element.text = text;
            return element;
        }

        // ---------------------------------------------------------------- waktu

        /// <summary>Jalankan sekali setelah sekian detik.</summary>
        public static IVisualElementScheduledItem Delay(this VisualElement element, float seconds, Action action)
            => element.schedule.Execute(action).StartingIn((long)(seconds * 1000f));

        /// <summary>Jalankan berulang tiap sekian detik. Hentikan dengan .Pause() pada hasilnya.</summary>
        public static IVisualElementScheduledItem Repeat(this VisualElement element, float seconds, Action action)
            => element.schedule.Execute(action).Every((long)(seconds * 1000f));

        /// <summary>
        /// Animasi nilai 0..1 selama sekian detik. onUpdate menerima progres (sudah lewat easing bila diberikan).
        /// Memakai waktu dari scheduler, jadi tetap jalan walau Time.timeScale = 0.
        /// </summary>
        public static IVisualElementScheduledItem Tween(this VisualElement element, float seconds,
                                                        Action<float> onUpdate, Action onDone = null,
                                                        Func<float, float> ease = null)
        {
            float elapsed = 0f;
            IVisualElementScheduledItem job = null;

            job = element.schedule.Execute((TimerState state) =>
            {
                elapsed += state.deltaTime / 1000f;
                float t = seconds <= 0f ? 1f : Mathf.Clamp01(elapsed / seconds);
                onUpdate?.Invoke(ease != null ? ease(t) : t);

                if (t >= 1f)
                {
                    job.Pause();
                    onDone?.Invoke();
                }
            }).Every(16);

            return job;
        }

        static readonly ConditionalWeakTable<Label, IVisualElementScheduledItem> counters
            = new ConditionalWeakTable<Label, IVisualElementScheduledItem>();

        /// <summary>Angka pada label berhitung dari "from" ke "to" (mis. gold bertambah). Pemanggilan baru membatalkan yang lama.</summary>
        public static void CountTo(this Label label, int from, int to, float seconds = 0.6f, string format = "N0")
        {
            if (label == null) return;

            if (counters.TryGetValue(label, out var running))
            {
                running.Pause();
                counters.Remove(label);
            }

            var job = label.Tween(seconds,
                t => label.text = Mathf.RoundToInt(Mathf.Lerp(from, to, t)).ToString(format, CultureInfo.InvariantCulture),
                () => counters.Remove(label));
            counters.Add(label, job);
        }
    }

    /// <summary>
    /// Pilih satu dari banyak elemen (slot inventori, kartu, pilihan karakter).
    /// var group = new SelectGroup(slots); group.Changed += (i, el) => ...; group.Select(0);
    /// </summary>
    public class SelectGroup
    {
        readonly List<VisualElement> items;
        readonly string selectedClass;

        public int Index { get; private set; } = -1;
        public event Action<int, VisualElement> Changed;

        public SelectGroup(IEnumerable<VisualElement> elements, string selectedClass = "slot-selected")
        {
            items = new List<VisualElement>(elements);
            this.selectedClass = selectedClass;

            for (int i = 0; i < items.Count; i++)
            {
                int captured = i;
                items[i].OnClick(() => Select(captured));
            }
        }

        /// <summary>Pilih berdasarkan indeks. -1 untuk membatalkan pilihan.</summary>
        public void Select(int index)
        {
            Index = index;
            for (int i = 0; i < items.Count; i++) items[i].EnableInClassList(selectedClass, i == index);
            Changed?.Invoke(index, index >= 0 && index < items.Count ? items[index] : null);
        }
    }

    /// <summary>Cooldown pada slot skill/item: .slot-cooldown menyusut dari penuh ke kosong.</summary>
    public static class Cooldown
    {
        public static bool IsCooling(VisualElement slot) => slot != null && slot.ClassListContains("slot-cooling");

        /// <summary>Mulai cooldown. Elemen .slot-cooldown dibuat otomatis kalau belum ada. Diabaikan bila masih cooldown.</summary>
        public static void Start(VisualElement slot, float seconds, Action done = null)
        {
            if (slot == null || IsCooling(slot)) return;

            var overlay = GetOverlay(slot);
            slot.AddToClassList("slot-cooling");
            overlay.style.height = Length.Percent(100f);

            slot.Tween(seconds,
                t => overlay.style.height = Length.Percent((1f - t) * 100f),
                () =>
                {
                    overlay.style.height = Length.Percent(0f);
                    slot.RemoveFromClassList("slot-cooling");
                    done?.Invoke();
                });
        }

        /// <summary>Kosongkan tampilan cooldown (tidak membatalkan animasi yang sedang berjalan).</summary>
        public static void Reset(VisualElement slot)
        {
            if (slot == null) return;
            GetOverlay(slot).style.height = Length.Percent(0f);
        }

        static VisualElement GetOverlay(VisualElement slot)
        {
            var overlay = slot.Q(className: "slot-cooldown");
            if (overlay != null) return overlay;

            overlay = new VisualElement { pickingMode = PickingMode.Ignore };
            overlay.AddToClassList("slot-cooldown");
            slot.Add(overlay);
            return overlay;
        }
    }

    /// <summary>
    /// Teks melayang naik lalu memudar (damage, heal, +XP).
    /// variant: damage | hit | heal | xp | gold. x/y relatif ke parent (parent diberi position absolute untuk anaknya).
    /// </summary>
    public static class FloatText
    {
        public static Label Spawn(VisualElement parent, string text, string variant = "hit",
                                  float x = 0f, float y = 0f, float seconds = 0.9f)
        {
            if (parent == null) return null;

            var label = new Label(text) { pickingMode = PickingMode.Ignore };
            label.AddToClassList("float-text");
            label.AddToClassList("float-" + variant);
            label.style.left = x;
            label.style.top = y;
            parent.Add(label);

            label.schedule.Execute(() => label.AddToClassList("float-go")).StartingIn(20);
            label.schedule.Execute(() => label.RemoveFromHierarchy()).StartingIn((long)(seconds * 1000f) + 100);
            return label;
        }
    }

    /// <summary>
    /// Pindah antar layar. Setiap layar adalah elemen ber-class "screen" dengan name "screen-&lt;nama&gt;"
    /// (lihat game.uss). Go = ganti seluruh layar, Push = tumpuk overlay (pause, pengaturan), Pop/Close = tutup overlay.
    /// </summary>
    public class ScreenRouter
    {
        readonly Dictionary<string, VisualElement> screens = new Dictionary<string, VisualElement>();
        readonly List<string> stack = new List<string>();

        /// <summary>Dipanggil saat layar teratas berganti: (dari, ke).</summary>
        public event Action<string, string> Changed;

        /// <summary>Nama layar paling atas (null bila belum ada).</summary>
        public string Top => stack.Count > 0 ? stack[stack.Count - 1] : null;
        /// <summary>Jumlah layar yang sedang tampil (dasar + overlay).</summary>
        public int Depth => stack.Count;

        public ScreenRouter(VisualElement root, string className = "screen", string prefix = "screen-")
        {
            root.Query(className: className).ForEach(element =>
            {
                string key = element.name ?? string.Empty;
                if (key.StartsWith(prefix, StringComparison.Ordinal)) key = key.Substring(prefix.Length);
                if (key.Length > 0) screens[key] = element;
            });

            Apply(null);   // sembunyikan semua sampai Go() dipanggil
        }

        public bool Has(string name) => screens.ContainsKey(name);
        public bool IsOpen(string name) => stack.Contains(name);
        public VisualElement Get(string name) => screens.TryGetValue(name, out var element) ? element : null;

        /// <summary>Tampilkan layar ini saja (menutup semua overlay). False bila layarnya tidak ada.</summary>
        public bool Go(string name)
        {
            if (!Has(name)) return false;
            string from = Top;
            stack.Clear();
            stack.Add(name);
            Apply(from);
            return true;
        }

        /// <summary>Tumpuk layar sebagai overlay di atas layar yang sedang tampil.</summary>
        public bool Push(string name)
        {
            if (!Has(name) || stack.Contains(name)) return false;
            string from = Top;
            stack.Add(name);
            Apply(from);
            return true;
        }

        /// <summary>Tutup overlay paling atas. Layar dasar tidak ikut tertutup.</summary>
        public bool Pop()
        {
            if (stack.Count <= 1) return false;
            string from = Top;
            stack.RemoveAt(stack.Count - 1);
            Apply(from);
            return true;
        }

        /// <summary>Tutup overlay tertentu, di mana pun posisinya di tumpukan.</summary>
        public bool Close(string name)
        {
            if (stack.Count <= 1 || stack[0] == name) return false;
            string from = Top;
            if (!stack.Remove(name)) return false;
            Apply(from);
            return true;
        }

        void Apply(string from)
        {
            foreach (var pair in screens)
                pair.Value.EnableInClassList("hidden", !stack.Contains(pair.Key));

            string to = Top;
            if (from != to) Changed?.Invoke(from, to);
        }
    }
}
